# 구현 계획

## 개요

본 구현 계획은 `docs/PRD.md`와 `docs/requirements.md`를 기준으로 작성했다. MVP의 1차 목표는 실제 LLM 완전 연동보다 브랜치 생성, 브랜치 관계 저장, 그래프 시각화 UI 검증이다.

## 1단계. 프로젝트 기반 구성

- 웹 서비스 기술 스택을 확정한다.
- `src/`와 `tests/` 하위 구조를 세분화한다.
- 메시지, 브랜치, 그래프 노드, 그래프 엣지, main 노드, 시작 노드의 기본 데이터 모델을 정의한다.
- Mock LLM 응답 계층과 실제 LLM API 연동 계층의 인터페이스를 분리한다.

## 2단계. 기본 채팅 흐름 구현

- 사용자 메시지 입력과 응답 출력 UI를 구현한다.
- 대화 세션과 메시지 목록 상태를 관리한다.
- Mock LLM 응답으로 기본 대화 흐름을 검증한다.
- 향후 실제 LLM API 교체가 가능하도록 호출 모듈을 분리한다.

## 3단계. 브랜치 데이터 구조 구현

- 특정 메시지에서 브랜치를 생성하는 동작을 구현한다.
- 브랜치의 부모 메시지, 부모 브랜치, 생성 시각, 활성 상태를 저장한다.
- 현재 브랜치와 원본 브랜치 간 이동 상태를 관리한다.
- 브랜치 삭제가 아니라 비활성화 상태 전환을 우선 구현한다.

## 4단계. 그래프 기반 시각화 구현

- 대화 브랜치를 노드와 엣지로 변환하는 로직을 구현한다.
- 사용자가 main 노드를 지정하고, 그래프에서 중심 줄기로 식별할 수 있게 한다.
- 그래프에서 분기 지점과 현재 위치를 표시한다.
- 그래프 클릭을 통해 해당 브랜치 대화로 이동하게 한다.
- 그래프 확대 및 축소 조작을 제공한다.
- 비활성 브랜치는 회색 표시 또는 접기 상태로 표현한다.

## 4-1단계. 시작 노드 탐색 UI 구현

- 사이드바의 1차 목록을 세션 목록이 아니라 시작 노드 목록으로 구성한다.
- 시작 노드 선택 시 해당 시작 노드의 하위 흐름을 미니 그래프로 표시한다.
- 미니 그래프 노드 hover 시 설명 또는 요약을 표시한다.
- 미니 그래프 노드 클릭 시 해당 노드 또는 세션의 채팅 화면으로 진입한다.
- 노드 또는 세션 진입 화면 우측 상단에 현재 흐름의 미니 그래프를 표시한다.
- 미니 그래프가 표시 영역을 초과하면 전체화면 그래프 전환 버튼을 노출한다.

## 5단계. 요약 미리보기 구현

- 브랜치별 대화 요약 데이터를 저장할 필드를 정의한다.
- 초기 버전에서는 Mock 요약 또는 간단한 규칙 기반 요약을 사용할 수 있다.
- LLM 자동 요약 연동 지점을 별도 모듈로 분리한다.
- 그래프 마우스 오버 시 요약 미리보기를 표시한다.

## 6단계. 사용자 테스트 준비

- 핵심 사용 시나리오를 기준으로 테스트 데이터를 구성한다.
- 만족도 조사 문항과 사용성 테스트 과제를 준비한다.
- 트래픽, 이용 시간, 브랜치 생성 횟수 등 측정 가능한 지표를 정의한다.
- 실제 사용자 모집 전 오류 처리와 빈 상태 UI를 점검한다.

## UI v1 구현 메모

- 기술 스택은 의존성 없는 정적 HTML, CSS, JavaScript로 시작했다.
- `src/index.html`, `src/styles.css`, `src/app.js`에서 첫 화면부터 채팅 작업 공간이 열리는 구조를 구현했다.
- Mock LLM 응답 계층은 `mockLlmProvider`로 분리하여 실제 API 제공자로 교체 가능한 형태를 유지했다.
- 상태 모델은 브랜치 ID, 부모 브랜치 ID, 부모 메시지 ID, 생성 시각, 활성 상태, 숨김 상태, 요약, 메시지 목록, 테스트 이벤트를 포함한다.
- 그래프는 SVG 기반 노드와 엣지로 구현했으며, 확대, 축소, 기본 배율 복귀, 노드 클릭 이동, 마우스 오버 요약 미리보기를 포함한다.
- 사용자 테스트 지표는 현재 브라우저 로컬 상태의 이벤트 로그로 기록한다.

## UI v2 Light 구현 메모

- `codex/ui-v2-light` 브랜치에서 v1을 보존하고 `src/v2.html`, `src/v2.css`, `src/v2.js`를 별도로 추가한다.
- UI v2는 밝은 Glass Morphism 스타일을 기본으로 하며, 좌측 대화 기록 사이드바와 중앙 채팅 영역을 기존 AI 채팅 서비스와 유사한 정보 구조로 배치한다.
- 우상단 현재 브랜치 표시는 배지와 팝오버 방식으로 구현한다. 팝오버에는 브랜치 경로, 분기 지점 요약, SVG 미니 그래프를 포함한다.
- 최근 대화 목록은 Mock 세션 데이터로 구현하고, 세션 선택 시 채팅 메시지와 현재 브랜치 상태가 함께 전환되도록 한다.
- 메시지 송수신은 실제 LLM API 없이 Mock 응답으로 처리한다. 사용자 메시지 추가 후 짧은 지연을 두고 AI 응답, 목록, 표, 인용문, 코드 블록 예시를 표시한다.
- 모바일에서는 사이드바를 drawer 형태로 접고, 하단 입력창은 고정된 glass card 형태를 유지한다.

## React 전환 계획 메모

- 프론트엔드는 정적 HTML, CSS, JavaScript 프로토타입을 기반으로 유지하지 않고 React 기반으로 재구현한다.
- 기존 `src/` 에셋은 장기 유지 대상이 아니며, React 전환 시 삭제하거나 별도 참고 자료로만 취급한다.
- 새 앱 디렉토리는 `frontend/`를 사용한다.
- 프론트엔드 기술 스택은 TypeScript 없이 React JavaScript 기반으로 시작한다.
- 스타일 방식은 Figma 디자인을 컴포넌트 단위로 옮기기 쉬운 CSS Modules를 우선 사용한다.
- React 전환 후에도 기존 MVP 요구사항인 채팅, 메시지 기준 브랜치 생성, 브랜치 전환, 그래프 시각화, 브랜치 비활성화, 요약 미리보기는 유지해야 한다.
- 초기 React 구조에서는 화면 컴포넌트, 브랜치 상태 모델, LLM 응답 제공자 인터페이스를 분리한다.

## React 앱 생성 절차 메모

- React 앱은 Vite 기반으로 생성한다.
- Node.js와 npm은 conda가 아니라 시스템에 설치된 런타임을 사용한다.
- 현재 확인된 로컬 버전은 Node.js `v24.18.0`, npm `11.16.0`이다.
- 프로젝트 루트에서 `npm create vite@latest frontend -- --template react` 명령으로 `frontend/` 디렉토리를 생성한다.
- 생성 후 `cd frontend`를 실행하고 `npm install`로 의존성을 설치한다.
- 개발 서버는 `npm run dev`로 실행한다.
- 빌드 검증은 `npm run build`로 수행한다.
- 팀원 간 차이를 줄이기 위해 `frontend/.nvmrc`와 `frontend/package.json`의 `engines`에 Node.js `24` 기준을 기록한다.
- `frontend/src/` 내부는 `components/`, `features/`, `lib/`, `styles/` 구조를 우선 사용한다.
- Mock LLM 제공자와 브랜치 상태 모델은 UI 컴포넌트와 분리하여 `frontend/src/lib/` 또는 `frontend/src/features/branch-chat/` 하위에 둔다.
- 기존 프로젝트 루트의 `docs/` 문서는 유지하고, React 앱 관련 실행 방법은 `README.md`와 `frontend/README.md` 중 최소 한 곳에 기록한다.

## React 앱 생성 상태 메모

- `frontend/` 디렉토리에 Vite React JavaScript 앱이 생성되었다.
- 생성된 주요 파일은 `frontend/package.json`, `frontend/vite.config.js`, `frontend/index.html`, `frontend/src/main.jsx`, `frontend/src/App.jsx`, `frontend/src/App.css`, `frontend/src/index.css`이다.
- `frontend/package-lock.json`과 `frontend/node_modules/`가 확인되었으므로 현재 로컬 상태에서는 의존성 설치가 완료된 상태로 판단한다.
- 현재 생성된 앱은 Vite 기본 예제 화면이며, 프로젝트의 브랜치 채팅 기능은 아직 구현되지 않았다.
- 다음 작업은 기본 예제 컴포넌트를 제거하고 MVP 요구사항에 맞는 채팅 화면, 브랜치 상태 모델, Mock LLM 계층을 React 구조로 옮기는 것이다.

## React 컴포넌트 분업 메모

- `AppShell`: 전체 레이아웃, 사이드바, 중앙 채팅 영역, 우측 상단 미니 그래프 배치를 담당한다.
- `StartNodeSidebar`: 시작 노드 목록 표시와 선택 상태 관리를 담당한다.
- `SidebarMiniGraph`: 선택된 시작 노드의 미니 그래프, 노드 hover 설명, 노드 클릭 진입을 담당한다.
- `ChatWorkspace`: 현재 노드 또는 세션의 메시지 목록, 입력창, 브랜치 생성 액션을 담당한다.
- `TopMiniGraph`: 노드 또는 세션 진입 화면의 우측 상단 미니 그래프를 담당한다.
- `FullscreenGraphModal`: 그래프 규모 초과 시 전체화면 그래프 표시와 닫기 동작을 담당한다.
- `MainNodeSelector`: 그래프 노드의 main 지정 및 변경 동작을 담당한다.
- `branchGraphModel`: 노드, 세션, 브랜치, 시작 노드, main 노드, 엣지 변환 로직을 UI와 분리해 관리한다.
- `mockLlmProvider`: 초기 개발 단계에서 실제 LLM API 없이 메시지 응답과 노드 설명 예시를 제공한다.

## React 프론트엔드 기틀 구현 상태

- Vite 기본 예제 화면을 제거하고 React 기반 노드 그래프 채팅 작업공간으로 교체했다.
- `frontend/src/features/branchGraph/branchGraphModel.js`에 루트 노드 조회, 노드 선택, 루트 선택, main 경로 계산, 메시지 추가, 부모 메시지 ID를 포함한 메시지 기준 브랜치 생성, SVG 그래프 레이아웃 계산 로직을 분리했다.
- `frontend/src/features/branchGraph/mockData.js`에 루트 노드 2개와 하위 노드, main 경로, 비활성 노드, 전체화면 전환 확인용 규모의 Mock 데이터를 구성했다.
- `frontend/src/features/branchGraph/mockLlmProvider.js`에 실제 LLM API로 교체 가능한 Mock 응답 함수를 분리했다.
- `frontend/src/components/`에 `StartNodeSidebar`, `MiniGraph`, `TopMiniGraph`, `FullscreenGraphModal`, `ChatWorkspace`를 추가하여 팀원이 컴포넌트 단위로 분업할 수 있는 기틀을 만들었다.
- 시작 노드는 `parentId === null`인 루트 노드만 표시한다.
- 노드와 세션은 1:1 관계로 관리한다.
- main은 사용자가 지정한 대상 노드부터 루트 노드까지의 부모 경로 전체를 파생 계산해 표시한다.
- 전체화면 그래프 버튼은 노드 수 8개 이상 또는 미니 그래프 레이아웃 폭 초과 기준으로 표시한다.
- 검증 명령은 `frontend/`에서 `npm run lint`, `npm run build`로 수행한다.

## React 중앙 채팅 랜딩 구현 상태

- 첨부 이미지의 ChatKHU형 정보 구조를 참고하여 초기 화면을 중앙 채팅 랜딩으로 변경했다.
- `frontend/src/components/ChatLanding.jsx`를 추가하여 시작 문구, 현재 루트 노드명, 대형 메시지 입력창, 프롬프트 모드 버튼을 표시한다.
- `새 채팅` 버튼을 누르면 중앙 랜딩 화면으로 돌아가도록 구현했다.
- 사이드바 루트 노드를 선택하면 해당 루트의 랜딩 상태를 유지하고, 미니 그래프 노드를 클릭하거나 메시지를 전송하면 중앙 채팅 세션으로 진입한다.
- 노드 진입 후에도 `ChatWorkspace`가 중앙 폭을 차지하도록 레이아웃을 변경했고, 미니 그래프는 우측 상단 보조 패널로 축소했다.
- 랜딩 화면에서는 우측 상단 미니 그래프를 숨겨 사용자의 첫 입력에 집중하도록 했다.

## React 상위 대화 컨텍스트 구현 상태

- `frontend/src/features/branchGraph/branchGraphModel.js`에 `getContextSectionsForNode`를 추가하여 루트 노드부터 현재 노드까지의 경로와 각 노드의 1:1 세션을 묶어 반환한다.
- `frontend/src/components/ChatWorkspace.jsx`는 현재 노드의 세션만 표시하지 않고, 상위 경로의 세션들을 `상위 노드`와 `현재 노드` 섹션으로 구분해 순서대로 표시한다.
- 예를 들어 `검증 계획` 노드에 진입하면 `프로젝트 기획`, `사용자 흐름`, `그래프 정책`, `검증 계획` 노드의 대화가 모두 표시된다.
- 상위 노드 메시지에서 `브랜치 생성`을 누르면 해당 메시지를 가진 상위 노드를 부모로 새 노드를 생성한다.
